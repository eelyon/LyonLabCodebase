from pylab import *
# from matplotlib.tri import Triangulation
#
# import tripy
#
#
# polygon = [(0,1), (-1, 0), (0, -1), (1, 0)]
# triangles = array( tripy.earclip(polygon)[0] ).T
# triangles[triangles==-1] = 0
# print(triangles)
# tri = Triangulation( *array(polygon).T, triangles = triangles )
#
# triplot(tri, color = 'grey')
# plot( *array(polygon).T, '--o' )
# axis('scaled')
# show()
