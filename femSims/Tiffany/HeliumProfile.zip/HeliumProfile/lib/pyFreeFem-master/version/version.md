# Versions

Latest test ran with:

```console
> pyFreeFem:
0.2

> Python:
3.7.3 (default, Jul 25 2020, 13:03:44) 
[GCC 8.3.0]

> FreeFem++:
3.610001 (date Κυρ 06 Ιαν 2019 11:39:39 μμ EET) 64bits

> Numpy:
1.16.2

> Matplotlib:
3.0.2
```
