from pylab import *

import sys
sys.path.append('./../../')

import pyFreeFem as pyff

# create initial mesh

script = pyff.edpScript('mesh Th = square(5, 5);')
script += pyff.OutputScript( Th = 'mesh' )
Th = script.get_output()['Th']

Th_initial = Th

# create refinement script

script = pyff.InputScript( Th = 'mesh' )
script += 'fespace Vh( Th, P1 );'
script +=  pyff.InputScript( u = 'vector' )
script += 'Th = adaptmesh( Th, u, iso = 1 );'
script += pyff.OutputScript( Th = 'mesh' )

# refine Th

for _ in range(3) :
    u = exp( - ( ( Th.x - .5 )**2 + ( Th.y - .5 )**2 )/.1**2 )
    Th = script.get_output( Th = Th, u = u )['Th']

# plots

fig_index = 0

for Th in [ Th_initial, Th ] :

    figure( fig_index, figsize = (5,5))

    Th.plot_triangles(color = 'k', lw = .5, alpha = .2)
    Th.plot_boundaries()

    axis('equal')
    axis('off')
    xticks([]), yticks([])

    # savefig( './../../figures/' + __file__.split('/')[-1].split('.')[0] + '_' + str(fig_index) + '.svg' , bbox_inches = 'tight' )

    fig_index += 1

show()
