from setuptools import setup, find_packages

setup(
    name='zeroheliumkit',
    version='0.4.1',
    packages=find_packages(include=['src', 'helpers', 'fem']), 
    install_requires=[]
)